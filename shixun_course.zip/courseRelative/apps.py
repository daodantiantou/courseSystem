from django.apps import AppConfig


class CourserelativeConfig(AppConfig):
    name = 'courseRelative'
