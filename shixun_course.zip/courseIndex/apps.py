from django.apps import AppConfig


class CourseindexConfig(AppConfig):
    name = 'courseIndex'
